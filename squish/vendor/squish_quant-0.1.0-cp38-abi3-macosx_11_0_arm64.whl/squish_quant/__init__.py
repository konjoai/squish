from .squish_quant import *

__doc__ = squish_quant.__doc__
if hasattr(squish_quant, "__all__"):
    __all__ = squish_quant.__all__